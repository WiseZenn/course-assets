function [x,y] = doolittle(A, b)
% 使用 Doolittle 分解法求解线性方程组 Ax=b
% code by huayue
% 输入: A是一个 n×n 矩阵, b 是一个 n×1 向量
% 输出: x 是一个 n×1 向量，满足 Ax=b

% 确定矩阵的大小
n = size(A, 1);

% 初始化 L 和 U 矩阵
L = eye(n);
U = zeros(n);

% 进行分解
for k = 1:n
    % 计算 U 的第 k 行
    for j = k:n
        U(k,j) = A(k,j) - L(k,1:k-1)*U(1:k-1,j);
    end
    
    % 计算 L 的第 k 列
    for i = k+1:n
        L(i,k) = (A(i,k) - L(i,1:k-1)*U(1:k-1,k))/U(k,k);
    end
end

% 解方程组 Ly=b 和 Ux=y
y = zeros(n, 1);
for i = 1:n
    y(i) = b(i) - L(i,1:i-1)*y(1:i-1);
end
x = zeros(n, 1);
for i = n:-1:1
    x(i) = (y(i) - U(i,i+1:n)*x(i+1:n))/U(i,i);
end
disp('L：');
disp(L);
disp('U：');
disp(U);
disp('x：');
disp(x)
end

function [x, iter] = jacobi(A, b, x0, epslion, maxiter)
% JACOBI使用Jacobi迭代法解线性方程组Ax = b
% code by zhongwei
%   [x, iter] = JACOBI(A, b, x0, tol, maxiter) 返回解向量x和迭代次数iter，直到解向量的误差小于tol，
%   或者迭代次数达到最大迭代次数maxiter为止。
%
%   A是大小为n x n的方阵。
%   b是长度为n的向量。
%   x0是初始解向量。
%   tol是解向量误差的期望容限。
%   maxiter是允许的最大迭代次数。

n = length(b); % 获取向量b的长度
iter = 0; % 将迭代计数器初始化为0
error = 1;
x = zeros(n,1);

while iter < maxiter && error > epslion % 在最大迭代次数内循环
    for i = 1:n % 循环遍历解向量中的每个元素
        s = 0;
        for j = 1:i-1
            s = s + A(i,j) * x0(j);
        end
        for j = i+1:n
            s = s + A(i,j) * x0(j);
        end
        x(i) = (-s + b(i))/A(i,i);
    end
    error = norm(x-x0,'inf');
    iter = iter + 1;
    x0 = x;
    fprintf('%2d  %.6e  x=(%1.7f %1.7f %1.7f)\n',iter,error,x.');
end
end



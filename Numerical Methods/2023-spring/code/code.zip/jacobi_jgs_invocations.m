% Jacobi,JGS函数调用
% code by zhongwei
% 输入系数矩阵
clear;clc;
A = [5 -1 1;
     1 -10 -2;
    -1  2 10];
b = [10; 27; 13];
% 设置迭代初始值
x0 = [0; 0; 0];
epslion = 1e-3;
maxiter = 100;
fprintf("Jacbi迭代法：\n");
[x_jacobi, iter_jacobi] = jacobi(A, b, x0, epslion, maxiter);
fprintf("JGS迭代法：\n");
[x_jgs, iter_jgs] = jgs(A, b, x0, epslion, maxiter);
% newton_solve函数调用
% code by zhongwei
clear;clc;
%% f = @(x) x^2 - c
% 定义矩阵用于确定方程
X1=[8;91;-8];
% 定义初始值矩阵
X0_1 = [3;10;-3];
tol = 1e-6;
max_iters = 100;
for k=1:length(X0_1)
    f = @(x) x^2 - abs(X1(k));
    df = @(x) 2*x;
    fprintf("f = x^2 - %d, ",abs(X1(k)));
    [x1(k), numiters_1(k)] = newton_solve(f, df, X0_1(k), tol, max_iters);
end

%% f = @(x) x^3 - c
X2=[7;200;-7];
X0_2 = [2;6;-2];
tol = 1e-6;
max_iters = 100;
for k=1:length(X0_2)
    f = @(x) x^3 - X2(k);
    df = @(x) 3*x^2;
    fprintf("f = x^2 - %d, ",X2(k));
    [x2(k), numiters_2(k)] = newton_solve(f, df, X0_2(k), tol, max_iters);
end
clear;clc;
format long;
x = linspace(0,1,6);
y = (x+1).^(x+1);
% 计算Lagrange插值多项式和点值多项式
[L,P] = lagrange_interpolation(x, y);
% 显示Lagrange插值多项式
% 以小数形式显示
L = expand(L);
L = vpa(L, 8);
disp(L);
%展示未化简的P,即未化简的Lagrange插值多项式
%disp(P)
% 在X处评估插值多项式
X = [-0.1,0.3,0.4,0.5,1.1];
% Y0用来存放f(x)的值,Y用来存放P(x)的值
Y = [];
Y0 = [];
for k =1:length(X)
    Y(k) = subs(L,X(k));
    Y0(k) = (X(k)+1).^(X(k)+1);
    fprintf('x=%f,P(x) = %.8f\n', X(k),Y(k));
    fprintf('x=%f,f(x) = %.8f\n', X(k),Y0(k));
end
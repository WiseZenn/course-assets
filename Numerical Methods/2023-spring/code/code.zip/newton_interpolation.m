function [D, N] = newton_interpolation(x, y)
% NEWTON_INTERPOLATIOPN计算使用差商方法得到的一组数据点的Newton插值多项式。
% code by zhongwei
% the last edition
% x是一列x坐标，y是相应的y坐标。
%
% [D, N] = NEWTON_INTERPOLATIOPN(x, y) 返回差分表D和插值多项式N。
%   示例：
%       x = [-1.1;-0.5;0.9;1.7];
%       y = [-1.12;0;1.80;2.20];
%       [D, N] = newton_interpolation(x, y);
%       disp(D);
%       disp(N);
%       X = 0;
%       Y = subs(N,X);
%       fprintf('f(x) = %.6f\n', Y);

% 获取数据点的数量
n = length(x);
% 将差分表初始化为零
D = zeros(n);
% 使用y坐标填充差分表的第一列
D(:,1) = y;
% 使用递推公式计算差商
for j = 2:n
    for i = j:n
        D(i,j) = (D(i,j-1) - D(i-1,j-1)) / (x(i) - x(i-j+1));
    end
end
% 使用差商计算插值多项式
N = D(1,1);
syms X;
for k = 2:n
    c = prod(X - x(1:k-1));
    N = N + D(k,k) * c;
end
% 以小数形式显示
% N = vpa(N, 6);
end

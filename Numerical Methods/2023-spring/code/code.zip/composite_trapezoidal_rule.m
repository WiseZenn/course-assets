function [T] = composite_trapezoidal_rule(f,a,b,n)
% 使用复化梯形公式计算不定积分
% code by zhongwei
% 输入参数：
% f - 被积函数
% a - 积分区间的下限
% b - 积分区间的上限
% n - 分割数
% 输出参数：
% T - 积分的近似值

h = (b-a)/n; % 梯形宽度
sum = 0;
for i = 1:1:n-1
    x = a + i*h;
    sum = sum + 2*f(x);
end
T = h*(f(a) + sum + f(b))/2; % 计算积分值
end

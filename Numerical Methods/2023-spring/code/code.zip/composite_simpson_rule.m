function [S] = composite_simpson_rule(f,a,b,n)
% 使用复合Simpson公式计算不定积分
% code by zhongwei
% 输入参数：
% f - 被积函数
% a - 积分区间的下限
% b - 积分区间的上限
% n - 分割数（偶数）
% 输出参数：
% S - 积分的近似值

h = (b-a)/n; % 梯形宽度
sum = 0;
for i = 0:1:n-1
    x = a + i*h;
    sum = sum + f(x) + 4*f(x+0.5*h) + f(x+h);
end
S = sum*h/6; % 计算积分值
end

% Cholesky函数调用
% code by zhongwei
clear;clc;
A = [4 -2 -4 3;
    -2 17 10 6;
    -4 10 9 2;
     3 6 2 15];
b = [10;3;-7;10];
cholesky(A,b);
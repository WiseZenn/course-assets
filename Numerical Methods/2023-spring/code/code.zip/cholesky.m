function [x] = cholesky(A,b)
% 使用 Cholesky 分解法求解线性方程组 Ax=b
%code by zhongwei
% A是一个 n×n 矩阵, b 是一个 n×1 向量
% x - 解向量
% 首先判断输入矩阵是不是对称正定矩阵, 如果不是则输出错误语句
if isequal(A,A') && all(eig(A) > 0)
    n = length(b);
    L = zeros(n,n);
    for j=1:n
        % 此时第j行主对角线元素还未赋值, 但主对角线元素前的元素已被赋值
        L(j,j) = sqrt(A(j,j) - L(j,:)*L(j,:)');
        for i=j+1:n
            L(i,j) = (A(i,j) - L(i,:)*L(j,:)')/L(j,j);
        end
    end
    disp(L)
    y = zeros(n,1);
    for i=1:n
        y(i) = (b(i) - L(i,:)*y)/L(i,i);
    end
    x = zeros(n,1);
    for i=n:-1:1
        x(i) = (y(i) - sum(L(i+1:n,i).*x(i+1:n)))/L(i,i);
    end
    disp('Y=')
    disp(y)
    disp('X=')
    disp(x)
else
    error('Input matrix is not symmetric positive definite')
end

% Cholesky函数调用
% code by zhongwei
clear;clc;
A = [4 -2 -4 3;
    -2 17 10 6;
    -4 10 9 2;
     3 6 2 15];
b = [10;3;-7;10];
cholesky(A,b);
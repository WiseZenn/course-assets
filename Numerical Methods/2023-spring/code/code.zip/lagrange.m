function L = lagrange(x, y, xx)
%lagrange插值
%the first edition
%code by zhongwei
% x: 数据点的x坐标
% y: 数据点的y坐标
% xx: 需要计算插值的点的x坐标
% L: 对应的插值多项式值

n = length(x); % 数据点数量
L = zeros(size(xx)); % 初始化插值多项式值

% 遍历每个插值点
for k = 1:length(xx)
    % 计算插值多项式在xx(k)处的值
    for i = 1:n
        % 计算插值基函数的值
        Lk = 1;
        for j = 1:n
            if j ~= i
                Lk = Lk * (xx(k) - x(j)) / (x(i) - x(j));
            end
        end
        % 累加插值多项式的值
        L(k) = L(k) + y(i) * Lk;
    end
end
end

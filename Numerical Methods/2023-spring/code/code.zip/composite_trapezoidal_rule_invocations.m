clear;clc;
% 定义被积函数
f = @(x) 2 + sin(2.*sqrt(x));
% 定义积分区间和分割数
a = 1;
b = 6;
% 定义分割数矩阵
N = [10,20,40,80,160];
% 定义积分值矩阵,用于存放积分结果
T = [];
% 定义误差存储矩阵
E = [];
% 定义矩阵h,用于存储区间长度
h = [];
% 计算积分的精确值
I = integral(f, a, b);
% 调用复化梯形公式计算积分值,循环计算不同分割数的积分值
for k =1:length(N)
    n = N(k);
    % 计算区间长度
    h(k) = (b-a)./n;
    T(k) = composite_trapezoidal_rule(f,a,b,n);
    % 计算和精确值之间的误差
    E(k) = T(k) - I;    
    % 输出积分值
   fprintf('复化梯形公式:n=%d,The approximate value of the integral is %.6f,the error is %.8f\n',n,T(k),E(k));
end
% 输出积分精确值 
fprintf('The exact value of the integral is %.10f\n',I);
% 合成输出总表
Table = [N',h',T',E'];
disp('Table:');
disp(Table);
% 输入数据点
x = linspace(0.1,0.6,6);
y = [0.172,0.323,0.484,0.69,1,1.579];
n = 6;
Y = 1./y;
% 构建设计矩阵
X = [1./x',ones(n,1), x'];
% 使用最小二乘法求解参数
beta = (X'*X)\(X'*Y');
M = X'*X;
disp(M);
N = X'*Y';
disp(N);
% 提取参数估计值
c0 = beta(1);
c1= beta(2);
c2 = beta(3);
fprintf('c0=%.6f,c1=%.6f,c2=%.6f\n',c0,c1,c2);
c = 1./c0;
a = c1.*c;
b = c2.*c;
fprintf('c=%.6f,a=%.6f,b=%.6f\n',c,a,b);
function [x, num_iters] = newton_solve(f, df, x0, tol, max_iters)
% newton_solve 使用牛顿迭代法求解非线性方程f(x)=0。
% code by zhongwei
%   [x, num_iters] = newton_solve(f, df, x0, tol, max_iters)
%   使用初始点X0，精度TOL和最大迭代次数MAX_ITERS对非线性方程f(x)=0进行求解。
%   F是一个函数句柄，DF是f的导数，输出X是方程的解，NUM_ITERS是迭代次数。
%
%   示例：
%       f = @(x) x^2 - 2;
%       df = @(x) 2*x;
%       x0 = 1;
%       tol = 1e-6;
%       max_iters = 100;
%       [x, num_iters] = newton_solve(f, df, x0, tol, max_iters);
%

x = x0;
num_iters = 1;

fprintf('初始值: x0 = %f\n', x0);

while num_iters < max_iters
    % 计算函数值和导数
    f_val = f(x);
    df_val = df(x);
    
    % 求解牛顿方程
    delta_x = -f_val / df_val;
    
    % 更新解
    x = x + delta_x;
    
    % 打印当前迭代的结果
    fprintf('第%d次迭代: x = %.9f, f(x) = %.9f\n', num_iters, x, f_val);
    
    % 检查是否满足精度要求
    if abs(f_val) < tol
        break
    end
    
    num_iters = num_iters + 1;
end

fprintf('经过%d次迭代，得到方程的近似根为: x = %.8f, f(x) = %.8f \n', num_iters,x, f(x));

end






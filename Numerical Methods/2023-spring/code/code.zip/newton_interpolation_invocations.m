x = [-1.15;-0.87;1.0;2.21];
y = [-0.8;0;1.2;1.8];
[D, N] = newton_interpolation(x, y);
disp(D);
% 以小数形式显示,保留6为小数
N = vpa(N, 6);
disp(N);
% 为Newton插值多项式赋值
X = 0;
Y = subs(N,X);
fprintf('f(x) = %.6f\n', Y);
%% 定义输入及基本量
%code by zhongwei
clear;clc;
% 定义被积函数
f = @(x) 2 + sin(2.*sqrt(x));
F = @(x) 2.*x -sqrt(x) .* cos(2.*sqrt(x)) + (sin(2.*sqrt(x)))/2
% 定义积分区间和分割数
a = 1;
b = 6;
% 定义分割数矩阵
N = [10,20,40,80,160];
% 计算积分的精确值
I = F(b) - F(a);

%% 复化梯形公式的调用
% 定义积分值矩阵,用于存放复化梯形积分结果
T=[];
% 定义矩阵E,用于存储复化梯形积分误差
E_T = [];
% 定义矩阵h,用于存储区间长度
h = [];
fprintf('------------复化梯形公式------------\n')
% 调用复化梯形公式计算积分值,循环计算不同分割数的积分值
for k =1:length(N)
    n = N(k);
    % 计算区间长度
    h(k) = (b-a)./n;
    T(k) = composite_trapezoidal_rule(f,a,b,n);
    % 计算和精确值之间的误差
    E_T(k) = T(k) - I;    
    % 输出积分值
    fprintf('复化梯形公式:n=%d,The approximate value of the integral is %.6f,the error is %.10f\n',n,T(k),E_T(k));
end

%% 复化Simpson公式的调用
% 定义积分值矩阵,用于存放复化Simpson积分结果
S=[];
% 定义矩阵E_S,用于存储复化Simpson积分误差
E_S = [];
% 定义矩阵h,用于存储区间长度
h = [];
fprintf('------------复化Simpson公式------------\n')
% 调用复化梯形公式计算积分值,循环计算不同分割数的积分值
for k =1:length(N)
    n = N(k);
    % 计算区间长度
    h(k) = (b-a)./n;
    S(k) = composite_simpson_rule(f,a,b,n);
    % 计算和精确值之间的误差
    E_S(k) = S(k) - I;    
    % 输出积分值
    fprintf('复化Simpson公式:n=%d,The approximate value of the integral is %.6f,the error is %.10f\n',n,S(k),E_S(k));
end

%% 最终输出
% 输出积分精确值 
fprintf('The exact value of the integral is %.10f\n',I);
% 合成输出总表
Table_T = [N',h',T',E_T'];
disp('复化梯形公式Table:');
disp(Table_T);
Table_S = [N',h',S',E_S'];
disp('复化Simpson公式Table:');
disp(Table_S);
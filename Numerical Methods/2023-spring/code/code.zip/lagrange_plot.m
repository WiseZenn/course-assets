%利用lagrange插值多项式绘图
%code by zhongwei
%a，b为左右区间端点
clear;
a = -5;
b = 5;
X = a:0.001:b;
%绘制函数图像
plot(X,1./(1+X.^2),'b','LineWidth',3);
hold on;
% 生成用于插值的点
n = [2,4,6,8,10];
for i=1:size(n,2)
    h = (b-a)/n(i);
    xx = a:h:b;
    for j=1:size(xx,1)
        yy=1./(1+xx.^2);
    end
    L = lagrange(xx, yy, X);
    plot( X, L, '-','LineWidth',3);
    idx = i;
    % 设置图例矩阵
    legend_str{idx} = ['$P_{', num2str(n(i)), '}(x)$'];
end
%添加图例
legend(legend_str, 'Interpreter', 'latex');
%添加图表标题
t = '$Plot$ $of$ $Interpolation$ $polynomial$($Plot$ $by$ $zhongwei$)';
title(t,'interpreter','latex')

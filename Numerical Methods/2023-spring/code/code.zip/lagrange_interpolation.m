function [L,P] = lagrange_interpolation(x, y)
% LAGRANGE_INTERPOLATIOPN 计算使用Lagrange插值方法得到的一组数据点的插值多项式。
% code by zhongwei
% the last edition
% x是一列x坐标，y是相应的y坐标。
% P用来存储lagrange基函数
% [L,P] = LAGRANGE_INTERPOLATIOPN(x, y) 返回Lagrange插值多项式L,P。
%   示例：
%       x = [144;169;196];
%       y = [12;13;14];
% 计算Lagrange插值多项式和点值多项式
%       [L,P] = lagrange_interpolation(x, y);
% 显示Lagrange插值多项式
%       disp(L);
%展示未化简的P,即未化简的Lagrange插值多项式
%       disp(P)
% 将X的值代入求值
%       X = 165;
%       Y = subs(L,X);
%       fprintf('f(x) = %.6f\n', Y);

% 获取数据点的数量
n = length(x);
% 计算点值多项式
syms X;
P = 0;
for k = 1:n
    Lk = 1;
    for j = 1:n
        if j ~= k
            Lk = Lk * (X - x(j)) / (x(k) - x(j));
        end
    end
    P = P + y(k) * Lk;
end
% 展示未化简的P,即未化简的Lagrange插值多项式
%disp(P)
% 返回插值多项式
L = simplify(P);
% 以小数形式显示
% L = vpa(L, 6);
end

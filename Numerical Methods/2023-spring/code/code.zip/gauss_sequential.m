function x = gauss_sequential(A, b)
% GAUSS_SEQUENTIAL 高斯顺序消元法求解线性方程组
% code by zhongwei
%   x = GAUSS_SEQUENTIAL(A, b) 使用高斯顺序消元法求解系数矩阵 A 和
%   常数向量 b 所表示的线性方程组 Ax = b，并返回方程组的解 x。
%
%   示例：
%       A = [2 1 -1; -3 -1 2; -2 1 2];
%       b = [8; -11; -3];
%       x = gauss_sequential(A, b);
%       disp(x); % 输出解向量

n = length(b);

% 消元过程
for k = 1:n-1
    % 选取主元
    for i = k+1:n
        factor = A(i,k) / A(k,k);
        A(i,k:n) = A(i,k:n) - factor * A(k,k:n);
        b(i) = b(i) - factor * b(k);
    end
end

% 回代过程
x = zeros(n, 1);
x(n) = b(n) / A(n,n);
for i = n-1:-1:1
    x(i) = (b(i) - A(i,i+1:n)*x(i+1:n)) / A(i,i);
end

% 显示消元后的矩阵
disp('消元后的矩阵：');
disp(A);
% 输出解向量
disp('解向量为: ')
disp(x);
end


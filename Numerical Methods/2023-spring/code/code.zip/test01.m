%% Numerical stability
clear; clc;

MaxN = 22; % 积分序列长度

%% 调用 Matlab 数值积分函数 integral 计算积分序列精确值
fprintf('---- 精确解 begin -----\n')
for k = 0:MaxN
    I = integral(@(x) exp(-1)*x.^k.*exp(x),0,1);
    fprintf('%d: I=%f\n',k,I);
end
fprintf('----- 精确解 end ------\n')

%% Algorithm 1 从前往后计算积分序列
fprintf('---- Algorithm 1 begin -----\n')
I = 1-1./exp(1);   % 设 I_{0} 的值
fprintf('%d: I=%f\n',0,I);
for k = 1:MaxN
    I = 1 - k*I;
    fprintf('%d: I=%f\n',k,I);
end
fprintf('---- Algorithm 1 end -----\n')

%% Algorithm 2 从后往前计算积分序列
fprintf('---- Algorithm 2 begin -----\n')
I = 0;  % 设 I_{MaxN} 的值为0
vals = zeros(MaxN,1);
vals(MaxN+1) = I;
for k = MaxN:-1:1
    I = (1 - I)./k;
    vals(k) = I;
end

for k = 0:MaxN
    fprintf('%d: I=%f\n',k,vals(k+1));
end
fprintf('---- Algorithm 2 end -----\n')
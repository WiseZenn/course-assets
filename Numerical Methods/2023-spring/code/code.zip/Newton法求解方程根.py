# 定义方程 f(x) = x**3 - 2*x - 5
def f(x):
    return x**2 - 8

# 定义方程的导数 f'(x) = 3*x**2 - 2
def df(x):
    return 2*x

# 定义初始值 x0 和误差限 eps
x0 = 3
eps = 1e-6

# 定义最大迭代次数 max_iter
max_iter = 100

# 进行牛顿迭代法
for i in range(max_iter):
    # 计算下一个近似值 x1
    x1 = x0 - f(x0)/df(x0)
    # 计算误差 err
    err = abs(x1 - x0)
    # 打印当前的迭代次数和近似值
    print(f"第{i+1}次迭代, x = {x1:.7f}")
    # 判断是否满足精度要求
    if err < eps:
        # 如果满足，输出结果并退出循环
        print(f"经过{i+1}次迭代，得到方程的近似根为 {x1:.6f}")
        break
    else:
        # 如果不满足，更新 x0 的值为 x1，并继续下一次迭代
        x0 = x1

% 高斯顺序消元法函数调用
% code by zhongwei
clear;clc;
A = [4 8 4 0;
    1 5 4 -3;
    1 4 7 2;
    1 3 0 -2];
b = [8;-4;10;-4];
x = gauss_sequential(A, b);
